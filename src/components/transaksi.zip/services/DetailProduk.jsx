import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Link } from "react-router-dom";

const DetailBarang = () => {
  const { id } = useParams(); // Extract the ID parameter from the URL
  const [barang, setBarang] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    const fetchBarang = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/barang/detail/${id}`);
        setBarang(response.data);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchBarang();
  }, [id]);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  if (!barang) return <p>Barang not found</p>;

  const handleAddToCart = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`http://localhost:8080/transaksi/add-to-cart/${barang.id}`, {
        quantity: quantity,
      });
      alert(response.data.message);
    } catch (error) {
      setError("Failed to add item to cart. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mt-3">
      <div className="row">
        <div className="col-md-6">
          <img src={`http://localhost:8080/uploads/${barang.gambar}`} alt={barang.nama} className="img-fluid" />
        </div>
        <div className="col-md-6">
          <div className="detail-barang">
            <h2>{barang.nama}</h2>
            <p>Category: {barang.kategori}</p>
            <p>Price: Rp. {barang.harga}</p>
            <p>Description: {barang.deskripsi}</p>
            <p>Stock: {barang.stok}</p>
            <div className="mb-3">
              <label htmlFor="quantity" className="form-label">Quantity:</label>
              <input type="number" id="quantity" className="form-control" min="1" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </div>
            <button className="btn btn-primary" onClick={handleAddToCart} disabled={loading}>Add to Cart</button>
            {error && <p className="text-danger mt-2">{error}</p>}
            <Link to="/keranjang" className="btn btn-secondary mt-2">View Cart</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DetailBarang;
