import React, { useState, useEffect } from "react";
import axios from "axios";

const Keranjang = () => {
  const [cartItems, setCartItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCartItems = async () => {
      try {
        const response = await axios.get(`http://localhost:8080/transaksi/keranjang`);
        setCartItems(response.data);
        calculateTotal(response.data);
        console.log("Cart items updated:", response.data); // Pesan perantara
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchCartItems();
  }, []);

  const calculateTotal = (items) => {
    let totalPrice = 0;
    items.forEach((item) => {
      totalPrice += item.harga * item.quantity;
    });
    setTotal(totalPrice);
  };

  const handleCheckout = async () => {
    try {
      await axios.post("http://localhost:8080/transaksi/checkout");
      alert("Checkout successful!");
      // Clear cart items after successful checkout
      setCartItems([]);
      setTotal(0);
    } catch (error) {
      alert("Checkout failed. Please try again later.");
    }
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  return (
    <div className="container mt-3">
      <h2>Keranjang Belanja</h2>
      {cartItems.length === 0 ? (
        <p>Cart empty</p> // Pesan "Cart empty" untuk keranjang kosong
      ) : (
        <div>
          {cartItems.map((item) => (
            <div key={item.id} className="card mb-3">
              <div className="row g-0">
                <div className="col-md-4">
                  <img
                    src={`http://localhost:8080/uploads/${item.gambar}`}
                    alt={item.nama}
                    className="img-fluid"
                  />
                </div>
                <div className="col-md-8">
                  <div className="card-body">
                    <h5 className="card-title">{item.nama}</h5>
                    <p className="card-text">Harga: Rp. {item.harga}</p>
                    <p className="card-text">Jumlah: {item.quantity}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
          <div className="text-end">
            <h5>Total: Rp. {total}</h5>
            <button className="btn btn-primary" onClick={handleCheckout}>
              Checkout
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Keranjang;
